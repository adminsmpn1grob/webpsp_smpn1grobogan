# example-profil-sekolah
Contoh profil sekolah sederhana
<a href="https://androjovi.github.io/example-profil-sekolah/">go</a>
